import os
import tempfile
from pathlib import Path

os.environ['CARTOVEILLE_DB'] = str(Path(tempfile.mkdtemp())/'test.sqlite3')
from fastapi.testclient import TestClient
from app import app
import base64
client = TestClient(app)
client.headers.update({"Authorization": "Basic " + base64.b64encode(b"test:test").decode()})

def test_auth_required():
    assert TestClient(app).get("/api/export").status_code == 401
    assert TestClient(app).get("/", headers={"Authorization": "Basic " + base64.b64encode(b"test:wrong").decode()}).status_code == 401

def test_health_and_company():
    assert client.get('/api/health').status_code == 200
    r = client.post('/api/companies', json={'name':'Cartonnerie Test','city':'Lyon','latitude':45.76,'longitude':4.84})
    assert r.status_code == 201
    cid=r.json()['id']
    assert client.get(f'/api/companies/{cid}').json()['company']['city']=='Lyon'
    assert client.post('/api/companies',json={'name':'Cartonnerie Test'}).status_code==409

def test_events_and_prices():
    cid=client.get('/api/companies').json()[0]['id']
    assert client.post('/api/events',json={'company_id':cid,'title':'Nouvelle ligne de production','source':'Test','url':'https://example.org/news'}).status_code==201
    assert client.post('/api/events',json={'title':'Doublon','source':'Test','url':'https://example.org/news'}).status_code==409
    assert client.post('/api/prices',json={'company_id':cid,'competitor':'Concurrent A','product':'Caisse B','quantity':10000,'unit_price':0.45,'observed_at':'2026-09-27'}).status_code==201
    e=client.post('/api/prices/estimate',json={'product':'Caisse B','quantity':10000}).json()
    assert e['status']=='indicative' and e['estimated_unit_price']==0.45
    assert client.post('/api/prices/estimate',json={'product':'Produit absent','quantity':100}).json()['status']=='insufficient_data'
    assert len(client.get('/api/export').json()['events'])==1
